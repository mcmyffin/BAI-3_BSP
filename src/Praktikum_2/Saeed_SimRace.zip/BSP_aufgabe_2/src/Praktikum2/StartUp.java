package Praktikum2;

/**
*
* @author saeed
*/
public class StartUp 
{
    public static void main(String[] args)
    {
        SimRace race = new SimRace();
        race.start();
    }
}
