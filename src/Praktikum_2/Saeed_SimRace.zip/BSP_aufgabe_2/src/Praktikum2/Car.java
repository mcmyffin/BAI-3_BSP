package Praktikum2;

import java.util.Random;

/**
*
* @author saeed
*/
public class Car extends Thread 
{
    private String _name;
    private int _zeit;
    private int _runden;
    private int _rundenDauer;
    Random rnd = new Random();
    
    public Car(String name){
        _name = name;
        _zeit = 0;
        _runden = 0;
        _rundenDauer = 0;
    }
    
    public String toString(){
        return _name + " Zeit " + _zeit;
    }
    
    public void addZeit(int zeit){
        _zeit += zeit;
    }
    
    public int get_zeit()
    {
        return _zeit;
    }

    @Override
    public void run()
    {
        while(_runden <= SimRace.ANZAHL_RUNDEN && !isInterrupted())
        {    
            _rundenDauer = rnd.nextInt(100);
            
            try
            {
                Thread.sleep(_rundenDauer);
            }
            catch (InterruptedException e)
            {
                System.err.println("Car wurde durch Interrupt geweckt!");
            }
            
            addZeit(_rundenDauer);
            _runden++;
        
        }
    }
    

}
