package Praktikum2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SimRace extends Thread{
    
    public static int ANZAHL_RUNDEN = 10;
    public static int ANZAHL_CARS = 5;
    public static boolean isAccident = false;
    
  
    /**
    *
    * @author saeed
    */
    public void run()
    {
        List<Car> cars = new ArrayList<Car>();
        
        for(int i = 1; i <= ANZAHL_CARS; i++)
        {
            cars.add(new Car("Wagen " + i));
        }
        
        for(Car c : cars)
        {
            c.start();
        }
        
        Accident unfall = new Accident(Thread.currentThread());
        unfall.start();
        
        for(Car c : cars)
        {
            try
            {
                c.join();
            }
            catch (InterruptedException e)
            {
                isAccident = true;
                for(Car u : cars)
                {
                    u.interrupt();
                }
            }
        }
        
        if(!isAccident)
        {
            unfall.interrupt();        
            Collections.sort(cars, new Comparator<Car>() {
                @Override
                public int compare(Car o1, Car o2) 
                {
                    return o1.get_zeit() - o2.get_zeit();
                };
            });
            
            System.out.println("Endstand");
            for(int i = 1; i <= ANZAHL_CARS; i++)
            {
                System.out.println(i + ". Platz: " + cars.get(i - 1).toString());
            }
        } 
        else
        {
            System.err.println("Unfall..........");
        }
    }
    
    
    
}

