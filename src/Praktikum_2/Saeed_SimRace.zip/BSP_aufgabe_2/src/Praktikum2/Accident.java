package Praktikum2;

import java.util.Random;

/**
*
* @author saeed
*/
public class Accident extends Thread
{
    Thread _trd = new Thread();
    
    public Accident(Thread trd)
    {
        _trd = trd;
    }
    
    public void run()
    {
        Random rnd = new Random();
        try
        {
            Thread.sleep(rnd.nextInt(4000));
            _trd.interrupt();
            
        }
        catch (InterruptedException e)
        {

        }
        
    }
    
}

